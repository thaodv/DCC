//
//  AIAuthHelperObject.h
//  DCC认证SDK DEMO
//
//  Created by wh on 2018/7/17.
//  Copyright © 2018年 wh. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef void(^AIAuthHelperObjectResultBlock)(id obj);
typedef void(^AIAuthHelperErrorRequest)(NSString *errorStr);
typedef void(^AIAuthHelperSuccessRequest)(NSString *successStr);
@interface AIAuthHelperObject : NSObject

/*
 *  外部控制器统一的监听失败和成功的请求方法
 */
+ (void)getRequestResposeSuccess:(AIAuthHelperSuccessRequest)successStr WithError:(AIAuthHelperErrorRequest)errorsStr;

/*
 *  dcc认证初始化数据 
 */
+ (void)authIdentifyWithRasPrivateKey:(NSString *)rasPrivateKey WithWalletPrivateKey:(NSString *)walletPrivateKey WithWalletAddress:(NSString *)walletAddress;

/*
 *  游客体验认证初始化数据
 */
+ (void)experienceIdentify;

/*
 *  实名认证初始化数据
 */
+ (void)identifyInitializationFomViewController:(UIViewController *)fromVC;

/*
 *  身份证正面扫描事件
 */
+ (void)identifyPositiveScanClickFomViewController:(UIViewController *)fromVC complete:(AIAuthHelperObjectResultBlock)complete;

/*
 *  身份证反面扫描事件
 */
+ (void)identifyContraryScanClickFomViewController:(UIViewController *)fromVC complete:(AIAuthHelperObjectResultBlock)complete;

/*
 *  身份证扫描事件数据回调
 */
+ (void)getIdentifyScanDataComplete:(AIAuthHelperObjectResultBlock)complete;

/*
 *  人脸扫描事件
 */
+ (void)faceScanClickFomViewController:(UIViewController *)fromVC complete:(AIAuthHelperObjectResultBlock)complete;

/*
 *  人脸认证事件
 */
+ (void)faceIdentifyClickFomViewController:(UIViewController *)fromVC complete:(AIAuthHelperObjectResultBlock)complete;

/*
 *  统一的监听失败和成功的请求方法
 */
+ (void)getRequestSuccess:(AIAuthHelperSuccessRequest)successStr WithError:(AIAuthHelperErrorRequest)errorsStr;

/*
 *  银行卡和本人关系认证
 */
+ (void)bankCardInitializationWithName:(NSString *)bankName WithCardNume:(NSString *)cardName WithPhoneNum:(NSString *)phoneNum WithBankCode:(NSString *)bankCode WithVc:(UIViewController *)fromVc;

/*
 *  获取绑定手机号验证码方法
 */
+ (void)getPhoneVerificationCode;

/*
 *  绑定手机号认证
 */
+ (void)bankCardPhoneCodeAuth:(NSString *)verfiCode FromViewController:(UIViewController *)fromVC;

/*
 *  手机运营商认证事件
 */
+ (void)phoneOperatorWithNum:(NSString *)phoneNum WithServicePwd:(NSString *)servicePwd WithVc:(UIViewController *)fromVC;

/*
 *  手机运营商认证状态查询更新接口
 */
+ (void)updatePhoneOperatorStatus;

/*
 *  用户退出登录时清除认证存储数据的方法
 */
+ (void)clearAllIdentifyData;

/*
 *  获取实名认证费用
 */
+ (void)getIdentifyFree:(AIAuthHelperObjectResultBlock)free;

/*
 *  获取银行卡认证费用
 */
+ (void)getBankCardFree:(AIAuthHelperObjectResultBlock)free;

/*
 *  获取手机运营商认证费用
 */
+ (void)getPhoneOpationFree:(AIAuthHelperObjectResultBlock)free;

/*
 *  处理手机运营商认证的特殊情况
 */
+ (void)handlePhoneSpecialEventComplete:(AIAuthHelperObjectResultBlock)complete;



@end
