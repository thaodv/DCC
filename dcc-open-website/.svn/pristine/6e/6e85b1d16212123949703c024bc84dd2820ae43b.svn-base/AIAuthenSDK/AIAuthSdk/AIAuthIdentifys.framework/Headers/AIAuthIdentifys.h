//
//  AIAuthIdentifys.h
//  AIAuthIdentifys
//
//  Created by wh on 2018/7/30.
//  Copyright © 2018年 wh. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <AIAuthIdentifys/AIAuthenStateObject.h>
#import <AIAuthIdentifys/AIIdentifyAuthenController.h>
#import <AIAuthIdentifys/AIBankCardAuthenController.h>
#import <AIAuthIdentifys/AIPhoneAuthenController.h>
#import <AIAuthIdentifys/AIIdentifyResultController.h>
#import <AIAuthIdentifys/AIBanCardkResultController.h>
#import <AIAuthIdentifys/AIPhoneResultController.h>
#import <AIAuthIdentifys/AIAuthHelperObject.h>


