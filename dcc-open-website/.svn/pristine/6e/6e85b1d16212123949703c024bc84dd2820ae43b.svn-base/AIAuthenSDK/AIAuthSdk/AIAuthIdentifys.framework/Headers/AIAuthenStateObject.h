//
//  AIAuthenStateObject.h
//  DCC认证SDK DEMO
//
//  Created by wh on 2018/7/12.
//  Copyright © 2018年 wh. All rights reserved.
//

#import <Foundation/Foundation.h>

//实名认证状态
typedef NS_ENUM(NSInteger,AICreditIDAuthenStatusType) {
    AICreditIDAuthenStatusTypeNone,//未认证
    AICreditIDAuthenStatusTypeAuthening,//进行中
    AICreditIDAuthenStatusTypeSuccess//已完成
};

//银行卡认证状态
typedef NS_ENUM(NSInteger,AICreditBankAuthenStatusType) {
    AICreditBankAuthenStatusTypeNone,//未认证
    AICreditBankAuthenStatusTypeAuthening,//进行中
    AICreditBankAuthenStatusTypeSuccess//已完成
};

//手机运营商证状态
typedef NS_ENUM(NSInteger,AICreditMobileOperatorAuthenStatusType) {
    AICreditMobileOperatorAuthenStatusTypeNone,//未认证
    AICreditMobileOperatorAuthenStatusTypeAuthening,//进行中
    AICreditMobileOperatorAuthenStatusTypeSuccess//已完成
};

@interface AIAuthenStateObject : NSObject

/*
 *  获取身份认证的结果状态
 */
+ (AICreditIDAuthenStatusType)getIDAuthenStates;

/*
 *  获取银行卡认证的结果状态
 */
+ (AICreditBankAuthenStatusType)getBankCardAuthenStates;

/*
 *  获取手机运营商认证的结果状态
 */
+ (AICreditMobileOperatorAuthenStatusType)getPhoneOperatorStates;

@end
