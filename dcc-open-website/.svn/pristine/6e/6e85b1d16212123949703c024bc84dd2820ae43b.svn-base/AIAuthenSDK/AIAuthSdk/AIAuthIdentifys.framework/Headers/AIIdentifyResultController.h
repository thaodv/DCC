//
//  AIIdentifyResultController.h
//  DCC认证SDK DEMO
//
//  Created by wh on 2018/7/12.
//  Copyright © 2018年 wh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AIIdentifyResultController : UIViewController

@end
