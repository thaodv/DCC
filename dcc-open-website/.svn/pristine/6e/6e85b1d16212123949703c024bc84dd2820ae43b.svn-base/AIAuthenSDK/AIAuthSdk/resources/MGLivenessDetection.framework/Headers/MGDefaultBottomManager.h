//
//  MGDefaultBottomManager.h
//  MGLivenessDetection
//
//  Created by megvii on 16/4/13.
//  Copyright © 2016Year megvii. All rights reserved.
//

#import "MGBaseBottomManager.h"
#import "MGCountDownRingView.h"
#import "MGCountDownTextView.h"

@interface MGDefaultBottomManager : MGBaseBottomManager

@end
