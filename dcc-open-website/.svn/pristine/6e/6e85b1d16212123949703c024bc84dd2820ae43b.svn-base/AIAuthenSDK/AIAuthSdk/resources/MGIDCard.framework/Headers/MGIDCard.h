//
//  MGIDCard.h
//  MGIDCard
//
//  Created by 张英堂 on 15/12/21.
//  Copyright © 2015年 megvii. All rights reserved.
//

#import <MGIDCard/MGIDCardManager.h>
#import <MGIDCard/MGIDCardDetectManager.h>

#import <MGIDCard/MGIDCardDetectBaseViewController.h>
#import <MGIDCard/MGIDCardViewController.h>

#import <MGIDCard/MGIDCardQualityAssessment.h>
#import <MGIDCard/MGIDCardConfig.h>
#import <MGIDCard/MGIDCardModel.h>
#import <MGIDCard/MGIDCardBundle.h>
