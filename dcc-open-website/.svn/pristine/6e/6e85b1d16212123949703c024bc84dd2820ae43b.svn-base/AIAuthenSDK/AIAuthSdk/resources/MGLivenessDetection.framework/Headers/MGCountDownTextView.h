//
//  CircularRing.h
//  LivenessDetection
//
//  Created by megvii on 15/1/13.
//  Copyright (c) 2015Year megvii. All rights reserved.
//

#import "MGBaseCountdownView.h"

@interface MGCountDownTextView : MGBaseCountdownView

/**
 *  显示倒计时的label
 */
@property (nonatomic, strong) UILabel *numLabel;



@end
