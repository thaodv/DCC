//
//  AIMainAutherController.m
//  DCC认证SDK DEMO
//
//  Created by wh on 2018/7/12.
//  Copyright © 2018年 wh. All rights reserved.
//

#import "AIMainAutherController.h"
#import <AIAuthIdentifys/AIAuthIdentifys.h>
////获取认证状态
//#import <AIAuthIdentifys/AIAuthenStateObject.h>
////实名认证界面
//#import <AIAuthIdentifys/AIIdentifyAuthenController.h>
////银行卡认证界面
//#import <AIAuthIdentifys/AIBankCardAuthenController.h>
////手机运营商认证界面
//#import <AIAuthIdentifys/AIPhoneAuthenController.h>
////实名认证成功结果界面
//#import <AIAuthIdentifys/AIIdentifyResultController.h>
////银行卡认证成功结果页面
//#import <AIAuthIdentifys/AIBanCardkResultController.h>
////运营商认证成功结果页面
//#import <AIAuthIdentifys/AIPhoneResultController.h>
////认证帮助工具类(初始化的方法,统一的监听请求状态...
//#import <AIAuthIdentifys/AIAuthHelperObject.h>

@interface AIMainAutherController ()

@property (nonatomic,strong)UIButton *identifyBtn;
@property (nonatomic,strong)UIButton *bankCardBtn;
@property (nonatomic,strong)UIButton *phoneOperatorBtn;

@end

@implementation AIMainAutherController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupSubViews];
    //用户体验初始化方法
    [AIAuthHelperObject experienceIdentify];
    //初始化方法,传参(用户rsa私钥,用户钱包私钥,用户地址)此方法一定要调用
//    [AIAuthHelperObject authIdentifyWithRasPrivateKey:<#(NSString *)#> WithWalletPrivateKey:<#(NSString *)#> WithWalletAddress:<#(NSString *)#>]
    //监听认证的网络请求状态
    [self getAuthRequestRespose];
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    //刷新认证状态
    [self reSetData];
}

- (void)getAuthRequestRespose{
    
    [AIAuthHelperObject getRequestResposeSuccess:^(NSString *successStr) {
        NSLog(@"%@",successStr);
    } WithError:^(NSString *errorStr) {
         NSLog(@"%@",errorStr);
    }];
}

#pragma mark -初始化控件布局
-(void)setupSubViews{
    self.navigationItem.title = @"认证";
    self.view.backgroundColor = [UIColor whiteColor];
    
    _identifyBtn = [[UIButton alloc]initWithFrame:CGRectMake(40, 120, [UIScreen mainScreen].bounds.size.width-80, 50)];
    [_identifyBtn setTitle:@"身份认证:未认证" forState:UIControlStateNormal];
    [_identifyBtn setBackgroundColor:[UIColor grayColor]];
    [_identifyBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_identifyBtn addTarget:self action:@selector(goIdentifyAutherVcClick) forControlEvents:UIControlEventTouchUpInside];
    _identifyBtn.layer.cornerRadius = 6;
    _identifyBtn.clipsToBounds = YES;
    [self.view addSubview:_identifyBtn];
    
    _bankCardBtn = [[UIButton alloc]initWithFrame:CGRectMake(40, 240, [UIScreen mainScreen].bounds.size.width-80, 50)];
    [_bankCardBtn setTitle:@"银行卡认证:未认证" forState:UIControlStateNormal];
    [_bankCardBtn setBackgroundColor:[UIColor grayColor]];
    [_bankCardBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_bankCardBtn addTarget:self action:@selector(goBankCardAutherVcClick) forControlEvents:UIControlEventTouchUpInside];
    _bankCardBtn.layer.cornerRadius = 6;
    _bankCardBtn.clipsToBounds = YES;
    [self.view addSubview:_bankCardBtn];
    
    _phoneOperatorBtn = [[UIButton alloc]initWithFrame:CGRectMake(40, 360, [UIScreen mainScreen].bounds.size.width-80, 50)];
    [_phoneOperatorBtn setTitle:@"运营商认证:未认证" forState:UIControlStateNormal];
    [_phoneOperatorBtn setBackgroundColor:[UIColor grayColor]];
    [_phoneOperatorBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_phoneOperatorBtn addTarget:self action:@selector(goPhoneOperatorAutherVcClick) forControlEvents:UIControlEventTouchUpInside];
    _phoneOperatorBtn.layer.cornerRadius = 6;
    _phoneOperatorBtn.clipsToBounds = YES;
    [self.view addSubview:_phoneOperatorBtn];
   
}

- (void)goIdentifyAutherVcClick{
    //获取实名认证状态,(AICreditIDAuthenStatusTypeNone)为未认证,跳转到实名认证界面
    if ([AIAuthenStateObject getIDAuthenStates] == AICreditIDAuthenStatusTypeNone) {
        AIIdentifyAuthenController *vc = [[AIIdentifyAuthenController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
    }
    //获取实名认证状态,(AICreditIDAuthenStatusTypeNone)为未认证,跳转到实名认证成功的结果界面
    if ([AIAuthenStateObject getIDAuthenStates]== AICreditIDAuthenStatusTypeSuccess) {
        AIIdentifyResultController *vc = [[AIIdentifyResultController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (void)goBankCardAutherVcClick{
    
    //跳转到银行卡认证界面前先判断是否实名认证通过,通过方可进行银行卡认证
 if ([AIAuthenStateObject getIDAuthenStates]== AICreditIDAuthenStatusTypeSuccess) {
     //获取银行卡认证状态,(AICreditBankAuthenStatusTypeNone)为未认证,跳转到银行卡认证界面
      if ([AIAuthenStateObject getBankCardAuthenStates]==  AICreditBankAuthenStatusTypeNone) {
        AIBankCardAuthenController *vc = [[AIBankCardAuthenController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
      }
     //获取银行卡认证状态,(AICreditBankAuthenStatusTypeSuccess)为已认证,跳转到银行卡认证成功结果界面
      if ([AIAuthenStateObject getBankCardAuthenStates]== AICreditBankAuthenStatusTypeSuccess) {
        AIBanCardkResultController *vc = [[AIBanCardkResultController alloc]init];
        [self.navigationController pushViewController:vc animated:YES];
      }
  }else{
      //请先完成实名认证(弹框提示)
      
  }
}

- (void)goPhoneOperatorAutherVcClick{
    
    //跳转到手机运营商认证界面前先判断是否实名认证通过,通过方可进行手机运营商认证
    if ([AIAuthenStateObject getIDAuthenStates]==AICreditIDAuthenStatusTypeSuccess) {
      //获取手机运营商认证状态,(AICreditMobileOperatorAuthenStatusTypeNone)为已认证,跳转到手机运营商认证界面
      if ([AIAuthenStateObject getPhoneOperatorStates]==AICreditMobileOperatorAuthenStatusTypeNone) {
        AIPhoneAuthenController *vc = [[AIPhoneAuthenController alloc]init];
        //必传,运营商认证可能多重跳转
        vc.fromVc = self;
        [self.navigationController pushViewController:vc animated:YES];
      }
    //获取手机运营商认证状态,(AICreditMobileOperatorAuthenStatusTypeNone)为已认证,跳转到手机运营商认证成功结果界面
      if ([AIAuthenStateObject getPhoneOperatorStates] == AICreditMobileOperatorAuthenStatusTypeSuccess) {
        AIPhoneResultController *vc = [[AIPhoneResultController alloc]init];
        //必传,运营商认证可能多重跳转
        vc.fromVc = self;
        [self.navigationController pushViewController:vc animated:YES];
      }
    }else{
        //请先完成实名认证(弹框提示)
        
    }
}

- (void)reSetData{
    
    if ([AIAuthenStateObject getIDAuthenStates]==  AICreditIDAuthenStatusTypeNone) {
        [_identifyBtn setTitle:@"身份认证:未认证" forState:UIControlStateNormal];
        [_identifyBtn setBackgroundColor:[UIColor grayColor]];
    }else if ([AIAuthenStateObject getIDAuthenStates]== AICreditIDAuthenStatusTypeAuthening) {
        [_identifyBtn setTitle:@"身份认证:认证中" forState:UIControlStateNormal];
        [_identifyBtn setBackgroundColor:[UIColor blueColor]];
    }else if ([AIAuthenStateObject getIDAuthenStates]==AICreditIDAuthenStatusTypeSuccess) {
        [_identifyBtn setTitle:@"身份认证:已认证" forState:UIControlStateNormal];
        [_identifyBtn setBackgroundColor:[UIColor orangeColor]];
    }
    
    if ([AIAuthenStateObject getBankCardAuthenStates] ==  AICreditBankAuthenStatusTypeNone) {
        [_bankCardBtn setTitle:@"银行卡认证:未认证" forState:UIControlStateNormal];
        [_bankCardBtn setBackgroundColor:[UIColor grayColor]];
    }else if ([AIAuthenStateObject getBankCardAuthenStates] == AICreditBankAuthenStatusTypeAuthening) {
        [_bankCardBtn setTitle:@"银行卡认证:认证中" forState:UIControlStateNormal];
        [_bankCardBtn setBackgroundColor:[UIColor blueColor]];
    }else if ([AIAuthenStateObject getBankCardAuthenStates] == AICreditBankAuthenStatusTypeSuccess) {
        [_bankCardBtn setTitle:@"银行卡认证:已认证" forState:UIControlStateNormal];
        [_bankCardBtn setBackgroundColor:[UIColor orangeColor]];
    }
    [self retSetPhoneOperatorStatus];
    
    //因为手机运营商认证结果需要处理,不能即时返回,所以需要一个方法去确认
    if ([AIAuthenStateObject getPhoneOperatorStates] == AICreditMobileOperatorAuthenStatusTypeAuthening)
    {
        
//    用户这里可以自己盖一个浮层阴影
        [AIAuthHelperObject updatePhoneOperatorStatus];
        __weak typeof(self) weakSelf  = self;
        //监听
        [AIAuthHelperObject getRequestSuccess:^(NSString *successStr) {
            // 如果有浮层阴影这里可以移除
            [weakSelf retSetPhoneOperatorStatus];
        } WithError:^(NSString *errorStr) {
            NSLog(@"errorStr = %@",errorStr);
        }];
    }
}

- (void)retSetPhoneOperatorStatus{
    
    if ([AIAuthenStateObject getPhoneOperatorStates] == AICreditMobileOperatorAuthenStatusTypeNone) {
        [_phoneOperatorBtn setTitle:@"运营商认证:未认证" forState:UIControlStateNormal];
        [_phoneOperatorBtn setBackgroundColor:[UIColor grayColor]];
        
    }else if ([AIAuthenStateObject getPhoneOperatorStates] == AICreditMobileOperatorAuthenStatusTypeAuthening) {
        
        [_phoneOperatorBtn setTitle:@"运营商认证:认证中" forState:UIControlStateNormal];
        [_phoneOperatorBtn setBackgroundColor:[UIColor blueColor]];
        
    }else if ([AIAuthenStateObject getPhoneOperatorStates] == AICreditMobileOperatorAuthenStatusTypeSuccess) {
        
        [_phoneOperatorBtn setTitle:@"运营商认证:已认证" forState:UIControlStateNormal];
        [_phoneOperatorBtn setBackgroundColor:[UIColor orangeColor]];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
