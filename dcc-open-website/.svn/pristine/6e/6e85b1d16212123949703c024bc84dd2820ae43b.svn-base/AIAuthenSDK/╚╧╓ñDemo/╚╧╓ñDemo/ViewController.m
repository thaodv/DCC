//
//  ViewController.m
//  认证Demo
//
//  Created by wh on 2018/7/21.
//  Copyright © 2018年 wh. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    // Do any additional setup after loading the view, typically from a nib.
}


@end
